## Muxic - An android app for playing music

#Preview

<img src="screenshots/one.png" width="400" height="500">
<img src="screenshots/two.png" width="400" height="500">
<img src="screenshots/three.png" width="400" height="500">