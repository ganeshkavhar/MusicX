package com.ganeshkavhar.musicx;

import java.io.File;
import java.util.List;

public class Constants {

    public static List<File> mySongs = null;
}
